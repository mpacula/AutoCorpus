?package(autocorpus):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="autocorpus" command="/usr/bin/autocorpus"
