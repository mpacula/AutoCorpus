# Defaults for autocorpus initscript
# sourced by /etc/init.d/autocorpus
# installed at /etc/default/autocorpus by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
